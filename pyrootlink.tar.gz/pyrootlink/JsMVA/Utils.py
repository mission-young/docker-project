# -*- coding: utf-8 -*-
#  @package JsMVA.Utils
#  @author Enric Tejedor <etejedor@cern.ch>
#  Utilities module.

import sys
if sys.version_info >= (3, 0):
    xrange = range
else:
    xrange = xrange
